require('dotenv').config();
const fs = require('fs');
const mongoose = require('mongoose');

// Ruta donde guardaste tu archivo .pem
const ca = [fs.readFileSync("/etc/ssl/certs/rds-combined-ca-bundle.pem")];

// La parte de la URI de conexión sin la contraseña
const mongoURIWithoutPassword = 'mongodb://everparkpruebafirstversion:@everpark-prueba.cluster-cdoeg4o0ugyn.eu-west-3.docdb.amazonaws.com:27017/everpark_database?ssl=true&replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false';

// Combina la URI con la contraseña desde el archivo .env
const mongoURI = mongoURIWithoutPassword.replace('@', `everparkpruebafirstversion:${process.env.DB_PASSWORD}@`);

mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  sslValidate: true,
  sslCA: ca
});

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  console.log("Conectado exitosamente a la base de datos de DocumentDB");
});


